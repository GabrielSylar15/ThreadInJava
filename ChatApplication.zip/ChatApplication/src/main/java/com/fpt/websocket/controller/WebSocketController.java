package com.fpt.websocket.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.fpt.websocket.config.WebSocketEventListener;
import com.fpt.websocket.model.Chat;
import com.fpt.websocket.model.User;

import jakarta.websocket.server.PathParam;

@Controller
public class WebSocketController {
	private static final Logger logger = LoggerFactory.getLogger(WebSocketController.class);
	
	List<String> members = new ArrayList<String>() {
	{
		add("A");
		add("B");
		add("C");
	}};
	
	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;
	
    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/publicChatRoom")
    public Chat sendMessage(@Payload Chat chat) {
    	logger.info("----------sendMessage--------------");
        return chat;
    }

    @MessageMapping("/chat.addUser")
    @SendTo("/topic/publicChatRoom")
    public Chat addUser(@Payload Chat chat, SimpMessageHeaderAccessor headerAccessor) {
        // Add username in web socket session
    	logger.info("----------addUser--------------");
        headerAccessor.getSessionAttributes().put("username", chat.getSender());
        headerAccessor.setUser(new User(chat.getSender()));
        return chat;
    }
    
    @MessageMapping("/toUser")
    public void sendMessageToSpecUser(@Payload Chat chat) {
    	logger.info("-------------sendMessageToSpecUser-----------");
        String destination = simpMessagingTemplate.getUserDestinationPrefix();
        logger.info("DESTNATION: "+chat.getSender());
    	simpMessagingTemplate.convertAndSendToUser(chat.getSender(), "/queue/messages", chat);
    }
    
    @MessageMapping("/group")
    public void sendMessageeToGroup(@Payload Chat chat) {
    	logger.info("----------Group Chat-----------");
    	String userName = chat.getSender();
    	simpMessagingTemplate.convertAndSend("/topic/"+chat.getSender(), chat);
    }
    
    @SendTo("/topic/group")
    public Chat sendMessageFromAdmin(@Payload Chat chat) {
    	return chat;
    }
}
