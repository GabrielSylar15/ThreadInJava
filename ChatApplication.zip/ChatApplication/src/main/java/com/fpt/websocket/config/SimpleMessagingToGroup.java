package com.fpt.websocket.config;

import java.util.Map;

import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import com.fpt.websocket.model.Chat;

public class SimpleMessagingToGroup extends SimpMessagingTemplate{

	

	public SimpleMessagingToGroup(MessageChannel messageChannel) {
		super(messageChannel);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void convertAndSend(String destination, Object payload) throws MessagingException {
		if(payload instanceof Chat) {
			Chat chat = (Chat) payload;
		
			convertAndSend(destination, payload, (Map<String, Object>) null);
		}
	}
	
	
}
