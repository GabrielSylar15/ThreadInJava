package com.fpt.websocket.model;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
public class Chat {
	public enum MessageType{
		CHAT, JOIN, LEAVE
	}
	private MessageType type;
	private String content;
	private String sender;
}
