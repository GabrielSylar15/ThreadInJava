 package com.fpt.websocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketApplication {
// https://dev.to/subhransu/realtime-chat-app-using-kafka-springboot-reactjs-and-websockets-lc
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(WebsocketApplication.class, args);
	}

}
